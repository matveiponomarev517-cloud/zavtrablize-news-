import os, json, hashlib, sqlite3, time, logging, re, urllib.request, urllib.parse
from datetime import datetime, timezone
import feedparser

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
DB=os.getenv("DB_PATH","news.db")
RSS=[
 "https://www.sciencedaily.com/rss/all.xml",
 "https://www.nasa.gov/rss/dyn/breaking_news.rss",
 "https://www.esa.int/rssfeed/Our_Activities/Space_Science",
 "https://feeds.arstechnica.com/arstechnica/science",
 "https://www.sciencedaily.com/rss/top/science.xml",
]
MAX_DAY=int(os.getenv("MAX_PER_DAY","3"))
TG_TOKEN=os.environ["TELEGRAM_BOT_TOKEN"]
TG_CHANNEL=os.getenv("TELEGRAM_CHANNEL","@zavtrablize")
GEMINI_KEY=os.environ["GEMINI_API_KEY"]
MODEL=os.getenv("GEMINI_MODEL","gemini-2.5-flash-lite")

def db():
 c=sqlite3.connect(DB); c.execute("""CREATE TABLE IF NOT EXISTS articles (id TEXT PRIMARY KEY,url TEXT,title TEXT,status TEXT,created TEXT,post TEXT,doc_url TEXT,error TEXT)"""); c.commit(); return c
def digest(url): return hashlib.sha256(url.encode()).hexdigest()
def request(url, data=None, headers=None):
 req=urllib.request.Request(url,data=data,headers=headers or {},method="POST" if data else "GET")
 with urllib.request.urlopen(req,timeout=35) as r: return r.read()
def tg(text):
 payload=json.dumps({"chat_id":TG_CHANNEL,"text":text,"disable_web_page_preview":False}).encode()
 request(f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",payload,{"Content-Type":"application/json"})
def gemini(title, url, summary):
 prompt=f"""Ты редактор научно-технологического канала «Завтра ближе». Оцени и подготовь материал по новости. Не выдумывай факты; опирайся на переданный текст и URL. Если новость слабая, неподтверждённая, рекламная, старая или не значимая, верни publish=false. Не выдавай пресс-релиз за независимое подтверждение.
Верни строго JSON: publish (boolean), reason (строка), headline (до 100 символов), post (русский пост 500-1100 символов, ясный, без кликбейта, заканчивается источником URL), article (развёрнутая статья 1200-2500 символов, с оговорками и источником).
Заголовок источника: {title}
URL: {url}
Описание RSS: {summary}"""
body=json.dumps({"contents":[{"parts":[{"text":prompt}]}],"generationConfig":{"temperature":0.25,"responseMimeType":"application/json"}}).encode()
 raw=request(f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key={GEMINI_KEY}",body,{"Content-Type":"application/json"})
 data=json.loads(raw); text=data["candidates"][0]["content"]["parts"][0]["text"]
 return json.loads(text)
def google_save(article):
 creds=os.getenv("GOOGLE_SERVICE_ACCOUNT_JSON")
 sheet=os.getenv("GOOGLE_SHEET_ID")
 if not creds or not sheet: return None
 try:
  from google.oauth2.service_account import Credentials
  from googleapiclient.discovery import build
  info=json.loads(creds)
  scopes=["https://www.googleapis.com/auth/spreadsheets","https://www.googleapis.com/auth/documents"]
  c=Credentials.from_service_account_info(info,scopes=scopes)
  sheets=build("sheets","v4",credentials=c,cache_discovery=False)
  docs=build("docs","v1",credentials=c,cache_discovery=False)
  doc=docs.documents().create(body={"title":article["headline"]}).execute()
  docid=doc["documentId"]
  content=article["article"]+"\n\nИсточник: "+article["url"]
  docs.documents().batchUpdate(documentId=docid,body={"requests":[{"insertText":{"location":{"index":1},"text":content}}]}).execute()
  durl="https://docs.google.com/document/d/"+docid+"/edit"
  sheets.spreadsheets().values().append(spreadsheetId=sheet,range="Контент!A:F",valueInputOption="USER_ENTERED",insertDataOption="INSERT_ROWS",body={"values":[[datetime.now(timezone.utc).isoformat(),article["headline"],article["url"],"Опубликовано",durl,article["post"]]]}).execute()
  return durl
 except Exception as e:
  logging.exception("Google saving failed")
  raise
def main():
 c=db()
 cutoff=datetime.now(timezone.utc).date().isoformat()
 rows=c.execute("SELECT COUNT(*) FROM articles WHERE status='published' AND created LIKE ?",(cutoff+"%",)).fetchone()[0]
 if rows>=MAX_DAY: logging.info("Daily cap reached"); return
 fresh=[]
 for feed in RSS:
  try:
   parsed=feedparser.parse(feed)
   for e in parsed.entries[:12]:
    url=e.get("link","").strip(); title=e.get("title","").strip()
    if not url or not title: continue
    uid=digest(url)
    if c.execute("SELECT 1 FROM articles WHERE id=?",(uid,)).fetchone(): continue
    published=e.get("published","")
    fresh.append((uid,url,title,e.get("summary",""),published))
  except Exception: logging.exception("Feed failure %s",feed)
 fresh.sort(key=lambda x:x[4],reverse=True)
 # Conservative processing: one article/run to limit API use and avoid flooding.
 for uid,url,title,summary,published in fresh[:1]:
  created=datetime.now(timezone.utc).isoformat()
  c.execute("INSERT OR IGNORE INTO articles VALUES(?,?,?,?,?,?,?,?)",(uid,url,title,"processing",created,None,None,None)); c.commit()
  try:
   result=gemini(title,url,summary)
   if not result.get("publish"):
    c.execute("UPDATE articles SET status='rejected',error=? WHERE id=?",(result.get("reason","filtered"),uid)); c.commit(); continue
   post=result.get("post","").strip()
   if not post or len(post)>3900: raise ValueError("Invalid post length")
   # Add source link if missing.
   if url not in post: post += "\n\nИсточник: "+url
   google_url=google_save({"headline":result["headline"],"article":result["article"],"url":url,"post":post})
   tg(post)
   c.execute("UPDATE articles SET status='published',post=?,doc_url=? WHERE id=?",(post,google_url,uid)); c.commit()
   logging.info("Published: %s",title)
   break
  except Exception as e:
   c.execute("UPDATE articles SET status='error',error=? WHERE id=?",(str(e)[:1000],uid)); c.commit()
   logging.exception("Article processing failed")
   # Report to admin via bot private chat if configured.
   admin=os.getenv("TELEGRAM_ADMIN_ID")
   if admin:
    try:
     payload=json.dumps({"chat_id":admin,"text":"⚠️ «Завтра ближе»: ошибка обработки новости.\n"+title+"\n"+str(e)[:500]}).encode()
     request(f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",payload,{"Content-Type":"application/json"})
    except: logging.exception("Error notification failed")
if __name__=="__main__": main()
