# Завтра ближе — автоматическая редакция

## Setup
1. Create a private repository and upload these files.
2. Repository Settings → Secrets and variables → Actions → New repository secret. Add:
   - `GEMINI_API_KEY`
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_CHANNEL` (value `@zavtrablize`)
   - `TELEGRAM_ADMIN_ID` (your numeric Telegram ID)
   - `GOOGLE_SERVICE_ACCOUNT_JSON` (entire service-account JSON)
   - `GOOGLE_SHEET_ID` (spreadsheet ID)
3. Google service account: enable Google Sheets API and Google Docs API in Google Cloud. Share the target spreadsheet with the service-account email as Editor.
4. Actions tab → enable workflows if prompted.

## Notes
Scheduled runs are approximate. Persistent duplicate prevention currently requires SQLite state to persist; GitHub-hosted runner filesystem is ephemeral, so the initial version needs a persistent store or committed state to make cross-run deduplication reliable. The current starter script is a baseline, not a verified production deployment. Do not enable automatic publication until a state persistence method is added and the integration test succeeds.
